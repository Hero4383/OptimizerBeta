# RuneLite Optimizer Plugin

A comprehensive optimization plugin for Old School RuneScape that helps players make informed decisions about quests, tasks, and progression paths.

## 🚀 Quick Start

### First Time Setup (Windows)

1. **Download the plugin**:
   ```bash
   git clone https://github.com/Hero4383/Optimizer.git
   cd Optimizer
   ```

2. **Run the automatic setup**:
   ```bash
   setup-optimizer.bat
   ```
   
   This will automatically:
   - Check for Java 21 (downloads if needed)
   - Download and configure Gradle
   - Build the plugin
   - Create launcher shortcuts
   - Guide you through RuneLite credential setup

3. **Launch the plugin**:
   - Run `launch-optimizer-dev.bat` for development mode
   - Or use the desktop shortcuts if you created them

## 🔧 Requirements

- **Windows** (tested on Windows 10/11)
- **Java 21** (automatically checked/prompted during setup)
- **RuneLite** with Jagex Launcher (for login credentials)
- **Git** (for cloning and updates)

## 📖 Usage

### For Jagex Account Users

If you use a Jagex account, you'll need to set up credentials for development mode:

1. Press `Windows key` → type `"RuneLite configure"`
2. In the "Client arguments" field, add: `--insecure-write-credentials`
3. Click `Save`
4. Launch RuneLite through Jagex launcher and log in once
5. This creates credentials for development mode

### For Regular OSRS Account Users

You can log in directly in development mode with your username/password.

## 🔄 Getting Updates

When new features or fixes are released:

1. **Run the update script**:
   ```bash
   update-optimizer.bat
   ```
   
   This will:
   - Pull the latest changes from GitHub
   - Rebuild the plugin automatically
   - Ready to use with the latest features

2. **Or manually update**:
   ```bash
   git pull origin main
   launch-optimizer-dev.bat
   ```

## 🛠 Development

### Available Scripts

- **`setup-optimizer.bat`** - Complete first-time setup
- **`launch-optimizer-dev.bat`** - Build + Launch (use when developing)
- **`launch-optimizer-quick.bat`** - Quick launch (no rebuild)
- **`update-optimizer.bat`** - Pull updates and rebuild

### Manual Building

If you prefer to build manually:

```bash
# Set up Gradle (if not done by setup script)
gradle clean build

# Launch RuneLite with plugin
gradle runRuneLite
```

## ⚡ Features

<!-- Add your plugin's specific features here -->
- Quest optimization and planning
- Task management and prioritization
- Progression path analysis
- Performance tracking
- Resource optimization

## 📁 File Structure

```
Optimizer/
├── setup-optimizer.bat          # Automated setup script
├── update-optimizer.bat         # Update script
├── launch-optimizer-dev.bat     # Development launcher
├── launch-optimizer-quick.bat   # Quick launcher
├── build.gradle                 # Build configuration
├── src/                         # Plugin source code
├── setup/                       # Downloaded tools (Gradle)
└── build/libs/                  # Built plugin JAR
```

## 🐛 Troubleshooting

### Common Issues

**"Java not found" error**:
- Download Java 21 from [Adoptium](https://adoptium.net/temurin/releases/)
- Select: OpenJDK 21 (LTS) - Windows x64 - JDK
- Restart the setup script

**Can't log in to RuneLite**:
- Make sure you've set up credentials (see "For Jagex Account Users" above)
- For regular accounts, try logging in directly in dev mode

**Plugin doesn't load**:
- Make sure the build was successful (green "BUILD SUCCESSFUL" message)
- Try running `launch-optimizer-dev.bat` instead of quick launch

**Gradle command not found**:
- Run `setup-optimizer.bat` again to reinstall Gradle
- Or use the launcher scripts which set up the environment automatically

### Getting Help

1. Check the [Issues](https://github.com/Hero4383/Optimizer/issues) page
2. Create a new issue with:
   - Your Windows version
   - Java version (`java -version`)
   - Full error message
   - Steps to reproduce

## 📄 License

This project is licensed under the BSD 2-Clause License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## ⚠️ Disclaimer

This plugin is provided "as is" and is not officially supported by RuneLite or Jagex. Use at your own risk. Make sure the plugin complies with [Jagex's 3rd Party Client Guidelines](https://secure.runescape.com/m=news/third-party-client-guidelines?oldschool=1).

## 🔗 Links

- [RuneLite](https://runelite.net/)
- [Plugin Development Guide](https://github.com/runelite/runelite/wiki/Developer-Guide)
- [Java 21 Download](https://adoptium.net/temurin/releases/)

---

**Made with ❤️ for the OSRS community**